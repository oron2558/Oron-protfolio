/* Dana Kadosh · interactions and motion.
   Focal moment: the hero opens like a gel coat curing (video settles from soft blur, the name rises, one brush stroke draws).
   Everything else explains state (method steps, track switch) or adds depth (3-layer hero parallax, almond reveals, gallery columns). */
(function () {
  var d = document;
  var html = d.documentElement;
  html.classList.add("js");

  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var fine = matchMedia("(hover: hover) and (pointer: fine)").matches;
  var isMobile = matchMedia("(max-width: 767px)").matches;
  var $ = function (s, r) { return (r || d).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || d).querySelectorAll(s)); };

  function init() {
    var yr = $("[data-year]");
    if (yr) yr.textContent = String(new Date().getFullYear());

    /* hero video: phone poster, pause toggle, reduced motion, off-screen pause */
    var hero = $(".hero");
    var v = $("[data-hero-video]");
    var tg = $("[data-video-toggle]");
    var userPaused = false;
    if (v) {
      if (isMobile) v.setAttribute("poster", "/media/hero-poster-m.webp");
      v.muted = true;
      var setPaused = function (p) {
        if (p) v.pause(); else { var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); }
        tg.classList.toggle("is-paused", p);
        tg.setAttribute("aria-label", p ? "הפעלת הווידאו" : "עצירת הווידאו");
      };
      if (reduce) { v.removeAttribute("autoplay"); userPaused = true; setPaused(true); }
      else setPaused(false);
      tg.addEventListener("click", function () { userPaused = !v.paused; setPaused(userPaused); });
      new IntersectionObserver(function (en) {
        if (userPaused) return;
        if (en[0].isIntersecting) setPaused(false); else v.pause();
      }).observe(hero);
    }

    /* nav background + phone dock */
    var nav = $("[data-nav]");
    var dock = $("[data-dock]");
    var footCta = $(".foot__cta");
    var pastHero = false, footIn = false;
    var syncDock = function () { if (dock) dock.classList.toggle("is-on", pastHero && !footIn); };
    new IntersectionObserver(function (en) { pastHero = !en[0].isIntersecting; syncDock(); }).observe(hero);
    if (footCta) new IntersectionObserver(function (en) { footIn = en[0].isIntersecting; syncDock(); }).observe(footCta);
    // the nav turns solid as soon as the page moves off the top
    new IntersectionObserver(function (en) { nav.classList.toggle("is-solid", !en[0].isIntersecting); }).observe(sentinel());
    function sentinel() { var s = d.createElement("div"); s.style.cssText = "position:absolute;top:0;height:30px;width:1px;pointer-events:none"; s.setAttribute("aria-hidden", "true"); $("#top").appendChild(s); return s; }

    /* advanced training: one day / extended */
    var seg = $("[data-seg]");
    var waAdv = $("[data-wa-adv]");
    var msgs = {
      one: "היי דנה, אשמח לשריין מקום בהשתלמות מניקור ג׳ל למקצועיות (יום אחד)",
      two: "היי דנה, אשמח לשריין מקום בהשתלמות מניקור ג׳ל למקצועיות (מסלול מורחב, 2 מפגשים)"
    };
    if (seg) {
      var btns = $$("[data-seg-btn]", seg);
      var pick = function (key, focus) {
        btns.forEach(function (b) {
          var on = b.getAttribute("data-seg-btn") === key;
          b.setAttribute("aria-checked", on ? "true" : "false");
          b.tabIndex = on ? 0 : -1;
          if (on && focus) b.focus();
        });
        seg.classList.toggle("is-two", key === "two");
        $$("[data-seg-panel]").forEach(function (p) { p.hidden = p.getAttribute("data-seg-panel") !== key; });
        if (waAdv) waAdv.href = "https://wa.me/972526054206?text=" + encodeURIComponent(msgs[key]);
      };
      btns.forEach(function (b, i) {
        b.addEventListener("click", function () { pick(b.getAttribute("data-seg-btn")); });
        b.addEventListener("keydown", function (e) {
          if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].indexOf(e.key) < 0) return;
          e.preventDefault();
          pick(btns[(i + 1) % btns.length].getAttribute("data-seg-btn"), true);
        });
      });
      pick("one");
    }

    /* map loads only on request (privacy + speed) */
    var mapBtn = $("[data-map-load]");
    if (mapBtn) mapBtn.addEventListener("click", function () {
      var f = d.createElement("iframe");
      f.src = "https://www.google.com/maps?q=" + encodeURIComponent("ניצנה 4, חדרה") + "&hl=he&z=16&output=embed";
      f.title = "מפה: רחוב ניצנה 4, חדרה";
      f.loading = "lazy";
      f.referrerPolicy = "no-referrer-when-downgrade";
      mapBtn.replaceWith(f);
    });

    /* accessibility statement */
    var dlg = $("[data-a11y]");
    var opener = $("[data-a11y-open]");
    if (dlg && opener) {
      opener.addEventListener("click", function () { if (dlg.showModal) dlg.showModal(); else dlg.setAttribute("open", ""); });
      $("[data-a11y-close]").addEventListener("click", function () { dlg.close(); });
      dlg.addEventListener("click", function (e) { if (e.target === dlg) dlg.close(); });
    }

    /* method: the active step drives the stage */
    var steps = $$(".step");
    var stage = $$(".method__m");
    var setStep = function (n) {
      steps.forEach(function (s, i) { s.classList.toggle("is-on", i === n); });
      stage.forEach(function (m, i) {
        var on = i === n;
        m.classList.toggle("is-on", on);
        if (m.tagName === "VIDEO") { if (on && !reduce) { m.preload = "auto"; var p = m.play(); if (p && p.catch) p.catch(function () {}); } else m.pause(); }
      });
    };
    var stepIO = new IntersectionObserver(function (en) {
      en.forEach(function (e) { if (e.isIntersecting) setStep(steps.indexOf(e.target)); });
    }, { rootMargin: "-45% 0px -45% 0px" });
    steps.forEach(function (s) { stepIO.observe(s); });

    /* small looping videos play only while visible */
    var loopIO = new IntersectionObserver(function (en) {
      en.forEach(function (e) {
        var vid = e.target;
        if (e.isIntersecting && !reduce) { vid.preload = "auto"; var p = vid.play(); if (p && p.catch) p.catch(function () {}); }
        else vid.pause();
      });
    }, { threshold: 0.25 });
    $$("[data-autoplay-inview], .step__m").forEach(function (el) { if (el.tagName === "VIDEO") loopIO.observe(el); });

    /* gloss: a soft highlight follows the pointer across almond frames, like light on cured gel */
    if (fine && !reduce) {
      $$(".gloss").forEach(function (el) {
        el.addEventListener("pointermove", function (e) {
          var r = el.getBoundingClientRect();
          el.style.setProperty("--gx", ((e.clientX - r.left) / r.width * 100).toFixed(1) + "%");
          el.style.setProperty("--gy", ((e.clientY - r.top) / r.height * 100).toFixed(1) + "%");
        });
      });
    }

    if (reduce || !window.gsap || !window.ScrollTrigger) return;
    motion(hero);
  }

  function motion(hero) {
    var gsap = window.gsap;
    var ST = window.ScrollTrigger;
    gsap.registerPlugin(ST);

    /* smooth scroll */
    if (window.Lenis) {
      var lenis = new window.Lenis({ lerp: 0.1, smoothWheel: true });
      lenis.on("scroll", ST.update);
      gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
      gsap.ticker.lagSmoothing(0);
      $$('a[href^="#"]').forEach(function (a) {
        a.addEventListener("click", function (e) {
          var id = a.getAttribute("href");
          var t = id.length > 1 ? $(id) : null;
          if (!t && id !== "#top") return;
          e.preventDefault();
          lenis.scrollTo(id === "#top" ? 0 : t, { offset: -76, duration: 1.2 });
          if (t) { t.setAttribute("tabindex", "-1"); t.focus({ preventScroll: true }); }
        });
      });
      $$("details").forEach(function (det) { det.addEventListener("toggle", function () { ST.refresh(); }); });
    }

    var media = $(".hero__media");
    var copy = $(".hero__copy");
    var stroke = $(".hero__stroke path");

    /* focal: the gel coat cures */
    var tl = gsap.timeline({ defaults: { ease: "expo.out" } });
    if (stroke) {
      var len = stroke.getTotalLength();
      gsap.set(stroke, { strokeDasharray: len, strokeDashoffset: len });
    }
    tl.from(media, { scale: 1.08, filter: "blur(10px)", duration: 1.6, clearProps: "filter" }, 0)
      .from(".hero__name-line", { yPercent: 60, opacity: 0, duration: 1.1 }, 0.15)
      .to(stroke, { strokeDashoffset: 0, duration: 1.1, ease: "power2.inOut" }, 0.45)
      .from([".hero__slogan", ".hero__sub", ".hero__ctas"], { y: 18, opacity: 0, duration: 0.8, stagger: 0.08 }, 0.55)
      .from(".paths__grid .path", { y: 40, opacity: 0, duration: 0.9, stagger: 0.08 }, 0.8);

    /* three depth layers on scroll: video (slow), copy (faster, fades), chooser cards (front, rise over the seam) */
    var sc = { trigger: hero, start: "top top", end: "bottom top", scrub: true };
    gsap.to(media, { yPercent: 14, ease: "none", scrollTrigger: sc });
    gsap.to(copy, { y: -90, opacity: 0.15, ease: "none", scrollTrigger: { trigger: hero, start: "top top", end: "bottom top", scrub: true } });
    gsap.fromTo(".paths .wrap", { y: 70 }, { y: -30, ease: "none", scrollTrigger: { trigger: ".paths", start: "top bottom", end: "bottom top", scrub: true } });

    /* pointer depth on the hero: layers drift in opposite directions, a warm light follows the cursor */
    if (fine) {
      var mx = gsap.quickTo(media, "x", { duration: 1.2, ease: "power3.out" });
      var my = gsap.quickTo(media, "y", { duration: 1.2, ease: "power3.out" });
      var cx = gsap.quickTo(copy, "x", { duration: 1.4, ease: "power3.out" });
      var gl = $(".hero__gloss");
      hero.addEventListener("pointermove", function (e) {
        var r = hero.getBoundingClientRect();
        var nx = (e.clientX - r.left) / r.width - 0.5;
        var ny = (e.clientY - r.top) / r.height - 0.5;
        mx(nx * -22); my(ny * -14); cx(nx * 10);
        gl.style.setProperty("--hx", ((nx + 0.5) * 100).toFixed(1) + "%");
        gl.style.setProperty("--hy", ((ny + 0.5) * 100).toFixed(1) + "%");
      });
      hero.addEventListener("pointerleave", function () { mx(0); my(0); cx(0); });

      /* magnetic primary CTAs */
      $$("[data-magnet]").forEach(function (b) {
        var bx = gsap.quickTo(b, "x", { duration: 0.5, ease: "power3.out" });
        var by = gsap.quickTo(b, "y", { duration: 0.5, ease: "power3.out" });
        b.addEventListener("pointermove", function (e) {
          var r = b.getBoundingClientRect();
          bx((e.clientX - r.left - r.width / 2) * 0.18);
          by((e.clientY - r.top - r.height / 2) * 0.28);
        });
        b.addEventListener("pointerleave", function () { bx(0); by(0); });
      });
    }

    /* almond reveals: the frame opens from the base like a nail being painted, the photo settles inside */
    $$('[data-reveal="almond"]').forEach(function (el) {
      gsap.fromTo(el, { clipPath: "inset(100% 0% 0% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", duration: 1.3, ease: "expo.out", scrollTrigger: { trigger: el, start: "top 85%", once: true } });
    });
    $$("[data-inner-parallax]").forEach(function (img) {
      gsap.fromTo(img, { yPercent: -6 }, { yPercent: 6, ease: "none", scrollTrigger: { trigger: img.parentElement, start: "top bottom", end: "bottom top", scrub: true } });
    });

    /* headings rise once */
    $$("[data-lines]").forEach(function (h) {
      gsap.from(h, { y: 26, opacity: 0, duration: 0.9, ease: "expo.out", scrollTrigger: { trigger: h, start: "top 88%", once: true } });
    });

    /* story: the brush line draws down the beats */
    var line = $(".beats__line");
    if (line) {
      gsap.fromTo(line, { scaleY: 0 }, { scaleY: 1, transformOrigin: "50% 0%", ease: "none", scrollTrigger: { trigger: ".beats", start: "top 70%", end: "bottom 60%", scrub: true } });
      $$(".beat").forEach(function (b) {
        gsap.from(b, { opacity: 0.2, x: 14, duration: 0.7, ease: "power3.out", scrollTrigger: { trigger: b, start: "top 78%", once: true } });
      });
    }

    /* credo: one manifesto line fills in word by word */
    var credo = $("[data-scrub-words]");
    if (credo) {
      var words = credo.textContent.trim().split(/\s+/);
      credo.setAttribute("aria-label", credo.textContent.trim());
      credo.innerHTML = words.map(function (w) { return '<span class="w" aria-hidden="true">' + w + "</span>"; }).join(" ");
      gsap.fromTo(credo.querySelectorAll(".w"), { opacity: 0.16 }, { opacity: 1, stagger: 0.1, ease: "none", scrollTrigger: { trigger: credo, start: "top 80%", end: "bottom 45%", scrub: true } });
      gsap.fromTo(".credo__bg img", { yPercent: -8 }, { yPercent: 8, ease: "none", scrollTrigger: { trigger: ".credo", start: "top bottom", end: "bottom top", scrub: true } });
    }

    /* kits and chat arrive in order */
    gsap.from(".kit", { y: 50, opacity: 0, duration: 0.9, stagger: 0.1, ease: "expo.out", scrollTrigger: { trigger: ".kits__stairs", start: "top 80%", once: true } });
    gsap.from(".bubble", { y: 24, opacity: 0, scale: 0.97, transformOrigin: "100% 0%", duration: 0.7, stagger: 0.28, ease: "expo.out", scrollTrigger: { trigger: ".chat", start: "top 75%", once: true } });

    /* gallery: columns travel at different speeds */
    ST.matchMedia({
      "(min-width: 768px)": function () {
        $$(".mosaic__col").forEach(function (col) {
          var s = parseFloat(col.getAttribute("data-speed") || "1");
          gsap.fromTo(col, { y: (1 - s) * -260 }, { y: (1 - s) * 260, ease: "none", scrollTrigger: { trigger: ".mosaic", start: "top bottom", end: "bottom top", scrub: true } });
        });
      }
    });

    addEventListener("load", function () { ST.refresh(); });
  }

  if (d.readyState === "loading") d.addEventListener("DOMContentLoaded", init);
  else init();
})();
